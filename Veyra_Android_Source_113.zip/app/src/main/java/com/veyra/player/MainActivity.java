package com.veyra.player;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerCallback;
import android.accounts.AccountManagerFuture;
import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.Gravity;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsIntent;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_PICK_ACCOUNT = 101;
    private static final int REQ_AUTH = 102;
    private static final String ACCOUNT_TYPE = "com.google";
    private static final String AUTH_TOKEN_TYPE = "oauth2:https://www.googleapis.com/auth/youtube.readonly";
    public static final String OAUTH_CLIENT_ID = "143368973290-fak6m5rep7uq5lkf85uemr0jcbmbnkom.apps.googleusercontent.com";

    private WebView webView;
    private WebView playerWebView;
    private FrameLayout playerOverlay;
    private FrameLayout root;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private Account selectedAccount;
    private String accessToken;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(8,10,15));
        getWindow().setNavigationBarColor(Color.rgb(8,10,15));

        prefs = getSharedPreferences("veyra", MODE_PRIVATE);
        String accountName = prefs.getString("account_name", null);
        if (accountName != null && !accountName.isEmpty()) selectedAccount = new Account(accountName, ACCOUNT_TYPE);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8,10,15));
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) s.setSafeBrowsingEnabled(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new Bridge(this), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view;
                customViewCallback = callback;
                webView.setVisibility(View.GONE);
                root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }
            @Override public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                webView.setVisibility(View.VISIBLE);
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                customViewCallback = null;
            }
        });
        // Load the UI with an HTTPS base origin instead of file://.
        // YouTube embedded playback requires a referrer/client origin; a file:// parent
        // can trigger player configuration error 153 in Android WebView.
        loadAppUi();
    }


    private void loadAppUi() {
        try (InputStream in = getAssets().open("index.html");
             BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder html = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) html.append(line).append('\n');
            webView.loadDataWithBaseURL(
                    "https://veyra.app/",
                    html.toString(),
                    "text/html",
                    "UTF-8",
                    null);
        } catch (Exception e) {
            webView.loadUrl("file:///android_asset/index.html");
        }
    }

    private void pickAccount() {
        Intent intent = AccountManager.newChooseAccountIntent(
                selectedAccount, null, new String[]{ACCOUNT_TYPE}, null, null, null, null);
        startActivityForResult(intent, REQ_PICK_ACCOUNT);
    }

    private void requestToken() {
        if (selectedAccount == null) { pickAccount(); return; }
        AccountManager am = AccountManager.get(this);
        am.getAuthToken(selectedAccount, AUTH_TOKEN_TYPE, null, this,
                new AccountManagerCallback<Bundle>() {
                    @Override public void run(AccountManagerFuture<Bundle> future) {
                        try {
                            Bundle b = future.getResult();
                            Intent consent = b.getParcelable(AccountManager.KEY_INTENT);
                            if (consent != null) {
                                startActivityForResult(consent, REQ_AUTH);
                                return;
                            }
                            String token = b.getString(AccountManager.KEY_AUTHTOKEN);
                            if (token != null && !token.isEmpty()) {
                                accessToken = token;
                                prefs.edit().putString("account_name", selectedAccount.name).apply();
                                sendAuthState(true, selectedAccount.name, null);
                                loadMyChannel();
                            } else sendAuthState(false, selectedAccount.name, "لم يتم استلام رمز الدخول من Google.");
                        } catch (Exception e) {
                            sendAuthState(false, selectedAccount != null ? selectedAccount.name : "", e.getMessage());
                        }
                    }
                }, null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_ACCOUNT && resultCode == RESULT_OK && data != null) {
            String name = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
            String type = data.getStringExtra(AccountManager.KEY_ACCOUNT_TYPE);
            if (name != null) {
                selectedAccount = new Account(name, type == null ? ACCOUNT_TYPE : type);
                accessToken = null;
                requestToken();
            }
        } else if (requestCode == REQ_AUTH) {
            if (resultCode == RESULT_OK) requestToken();
            else sendAuthState(false, selectedAccount != null ? selectedAccount.name : "", "تم إلغاء منح الصلاحية.");
        }
    }

    private void sendAuthState(boolean ok, String email, String error) {
        JSONObject j = new JSONObject();
        try { j.put("ok", ok); j.put("email", email == null ? "" : email); j.put("error", error == null ? JSONObject.NULL : error); }
        catch (JSONException ignored) {}
        js("window.Veyra && Veyra.onAuthState(" + j.toString() + ")");
    }

    private interface TokenWork { void run(String token) throws Exception; }
    private void withToken(TokenWork work) {
        if (accessToken == null) {
            runOnUiThread(this::requestToken);
            js("window.Veyra && Veyra.onError({where:'auth',message:'يتم الآن طلب صلاحية حساب Google. حاول مرة أخرى بعد اكتمال تسجيل الدخول.'})");
            return;
        }
        io.execute(() -> {
            try { work.run(accessToken); }
            catch (Exception e) { sendError("api", e.getMessage()); }
        });
    }

    private String apiGet(String path, String token) throws Exception {
        URL url = new URL("https://www.googleapis.com/youtube/v3/" + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Authorization", "Bearer " + token);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "Veyra/1.1.3 Android");
        int code = c.getResponseCode();
        InputStream in = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(); String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        if (code == 401 && selectedAccount != null) {
            AccountManager.get(this).invalidateAuthToken(ACCOUNT_TYPE, token);
            accessToken = null;
        }
        if (code < 200 || code >= 300) throw new Exception("YouTube API " + code + ": " + sb);
        return sb.toString();
    }

    private void loadMyChannel() {
        withToken(token -> {
            String json = apiGet("channels?part=snippet,contentDetails,statistics&mine=true", token);
            js("window.Veyra && Veyra.onChannel(" + json + ")");
        });
    }

    private void loadSubscriptions() {
        withToken(token -> {
            String json = apiGet("subscriptions?part=snippet,contentDetails&mine=true&maxResults=50&order=alphabetical", token);
            js("window.Veyra && Veyra.onSubscriptions(" + json + ")");
        });
    }

    private void loadLikes() {
        withToken(token -> {
            JSONObject channels = new JSONObject(apiGet("channels?part=contentDetails&mine=true", token));
            JSONArray items = channels.optJSONArray("items");
            if (items == null || items.length() == 0) throw new Exception("لم يتم العثور على قناة YouTube لهذا الحساب.");
            String playlist = items.getJSONObject(0).getJSONObject("contentDetails").getJSONObject("relatedPlaylists").optString("likes");
            if (playlist.isEmpty()) throw new Exception("قائمة الإعجابات غير متاحة.");
            String json = apiGet("playlistItems?part=snippet,contentDetails&maxResults=50&playlistId=" + URLEncoder.encode(playlist, "UTF-8"), token);
            js("window.Veyra && Veyra.onLikes(" + json + ")");
        });
    }

    private void search(String query) {
        withToken(token -> {
            String q = URLEncoder.encode(query, "UTF-8");
            String json = apiGet("search?part=snippet&type=video&maxResults=30&q=" + q, token);
            js("window.Veyra && Veyra.onSearch(" + json + ")");
        });
    }

    private void loadPlaylists() {
        withToken(token -> {
            String json = apiGet("playlists?part=snippet,contentDetails&mine=true&maxResults=25", token);
            js("window.Veyra && Veyra.onPlaylists(" + json + ")");
        });
    }

    private void loadHome() {
        withToken(token -> {
            String json = apiGet("videos?part=snippet,contentDetails,statistics&chart=mostPopular&maxResults=25", token);
            js("window.Veyra && Veyra.onHome(" + json + ")");
        });
    }

    private void loadShorts() {
        withToken(token -> {
            String q = URLEncoder.encode("#shorts", "UTF-8");
            String json = apiGet("search?part=snippet&type=video&videoDuration=short&maxResults=16&q=" + q, token);
            js("window.Veyra && Veyra.onShorts(" + json + ")");
        });
    }

    private void sendError(String where, String msg) {
        JSONObject j = new JSONObject();
        try { j.put("where", where); j.put("message", msg == null ? "خطأ غير معروف" : msg); } catch (JSONException ignored) {}
        js("window.Veyra && Veyra.onError(" + j.toString() + ")");
    }

    private void js(String script) {
        runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }

    private void logout() {
        if (accessToken != null) AccountManager.get(this).invalidateAuthToken(ACCOUNT_TYPE, accessToken);
        accessToken = null; selectedAccount = null;
        prefs.edit().remove("account_name").apply();
        sendAuthState(false, "", null);
        js("window.Veyra && Veyra.resetAccount()");
    }

    private void openYoutubePlayer(String videoId) {
        if (videoId == null || !videoId.matches("[A-Za-z0-9_-]{6,20}")) {
            sendError("player", "معرّف الفيديو غير صالح.");
            return;
        }
        closeYoutubePlayer();

        playerOverlay = new FrameLayout(this);
        playerOverlay.setBackgroundColor(Color.BLACK);

        playerWebView = new WebView(this);
        WebSettings ps = playerWebView.getSettings();
        ps.setJavaScriptEnabled(true);
        ps.setDomStorageEnabled(true);
        ps.setMediaPlaybackRequiresUserGesture(false);
        ps.setLoadWithOverviewMode(true);
        ps.setUseWideViewPort(true);
        ps.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ps.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(playerWebView, true);

        playerWebView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String host = u.getHost() == null ? "" : u.getHost();
                if ("https".equals(u.getScheme()) && (host.endsWith("youtube.com") || host.endsWith("googlevideo.com") || host.endsWith("ytimg.com"))) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });
        playerWebView.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view;
                customViewCallback = callback;
                playerWebView.setVisibility(View.GONE);
                root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }
            @Override public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                if (playerWebView != null) playerWebView.setVisibility(View.VISIBLE);
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                customViewCallback = null;
            }
        });

        playerOverlay.addView(playerWebView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextColor(Color.WHITE);
        close.setTextSize(26f);
        close.setGravity(Gravity.CENTER);
        close.setBackgroundColor(Color.argb(170, 0, 0, 0));
        close.setOnClickListener(v -> closeYoutubePlayer());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(64, 64, Gravity.TOP | Gravity.END);
        cp.setMargins(0, 18, 18, 0);
        playerOverlay.addView(close, cp);

        root.addView(playerOverlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        String url = "https://www.youtube.com/embed/" + Uri.encode(videoId)
                + "?autoplay=1&playsinline=1&rel=0";
        Map<String, String> headers = new HashMap<>();
        // YouTube requires HTTP Referer (or equivalent client identification)
        // for embedded playback in Android WebView. The package ID is used as
        // a stable app identity, per YouTube's API Client Identity guidance.
        headers.put("Referer", "https://com.veyra.player/");
        playerWebView.loadUrl(url, headers);
    }

    private void closeYoutubePlayer() {
        if (customView != null && playerWebView != null) {
            try { ((WebChromeClient) playerWebView.getWebChromeClient()).onHideCustomView(); } catch (Exception ignored) {}
        }
        if (playerOverlay != null) {
            root.removeView(playerOverlay);
            playerOverlay = null;
        }
        if (playerWebView != null) {
            try { playerWebView.stopLoading(); playerWebView.loadUrl("about:blank"); playerWebView.destroy(); } catch (Exception ignored) {}
            playerWebView = null;
        }
    }


    /**
     * Opens YouTube in a secure browser-backed Custom Tab. This intentionally does
     * not perform Google sign-in inside WebView: Google blocks OAuth authentication
     * in embedded user agents. A Custom Tab reuses the user's supported browser
     * session, so pages such as YouTube History can show the account's real data
     * when that browser is signed in.
     */
    private void openYouTubeWeb(String url) {
        if (url == null) return;
        Uri uri;
        try { uri = Uri.parse(url); } catch (Exception e) { return; }
        String scheme = uri.getScheme() == null ? "" : uri.getScheme();
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
        if (!"https".equals(scheme) || !(host.equals("youtube.com") || host.endsWith(".youtube.com"))) {
            sendError("youtube_web", "لا يمكن فتح هذا الرابط داخل جلسة YouTube.");
            return;
        }
        runOnUiThread(() -> {
            try {
                CustomTabColorSchemeParams colors = new CustomTabColorSchemeParams.Builder()
                        .setToolbarColor(Color.rgb(15, 15, 15))
                        .setNavigationBarColor(Color.rgb(15, 15, 15))
                        .build();
                CustomTabsIntent tab = new CustomTabsIntent.Builder()
                        .setShowTitle(true)
                        .setUrlBarHidingEnabled(true)
                        .setDefaultColorSchemeParams(colors)
                        .build();
                tab.intent.putExtra(Intent.EXTRA_REFERRER, Uri.parse("android-app://" + getPackageName()));
                tab.launchUrl(MainActivity.this, uri);
            } catch (Exception e) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                catch (Exception ignored) { sendError("youtube_web", "لم يتم العثور على متصفح مدعوم."); }
            }
        });
    }


    private void setSystemTheme(String mode) {
        boolean dark = !"light".equalsIgnoreCase(mode);
        runOnUiThread(() -> {
            int bg = dark ? Color.rgb(15, 15, 15) : Color.WHITE;
            getWindow().setStatusBarColor(bg);
            getWindow().setNavigationBarColor(bg);
            if (root != null) root.setBackgroundColor(bg);
            int flags = 0;
            if (!dark && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (!dark && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        });
    }

    private void enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                PictureInPictureParams p = new PictureInPictureParams.Builder().setAspectRatio(new Rational(16, 9)).build();
                enterPictureInPictureMode(p);
            } catch (Exception e) { sendError("pip", e.getMessage()); }
        }
    }

    @Override public void onBackPressed() {
        if (customView != null) {
            try {
                WebView target = playerWebView != null ? playerWebView : webView;
                ((WebChromeClient) target.getWebChromeClient()).onHideCustomView();
            } catch (Exception ignored) {}
            return;
        }
        if (playerOverlay != null) { closeYoutubePlayer(); return; }
        if (webView == null) { finish(); return; }

        // Veyra navigation rule: any internal page -> Home; Home -> exit.
        // If a video page is open, JavaScript minimizes it to the mini player first.
        webView.evaluateJavascript(
                "(function(){try{return (window.Veyra&&Veyra.handleAndroidBack)?Veyra.handleAndroidBack():'exit'}catch(e){return 'exit'}})()",
                value -> {
                    if (value == null || "\"exit\"".equals(value) || "null".equals(value)) finish();
                });
    }

    @Override protected void onDestroy() {
        closeYoutubePlayer();
        io.shutdownNow();
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }

    public class Bridge {
        private final Context context;
        Bridge(Context c) { context = c; }
        @JavascriptInterface public void login() { runOnUiThread(MainActivity.this::pickAccount); }
        @JavascriptInterface public void refreshToken() { runOnUiThread(MainActivity.this::requestToken); }
        @JavascriptInterface public void logout() { runOnUiThread(MainActivity.this::logout); }
        @JavascriptInterface public void loadChannel() { loadMyChannel(); }
        @JavascriptInterface public void loadSubscriptions() { MainActivity.this.loadSubscriptions(); }
        @JavascriptInterface public void loadLikes() { MainActivity.this.loadLikes(); }
        @JavascriptInterface public void loadPlaylists() { MainActivity.this.loadPlaylists(); }
        @JavascriptInterface public void loadHome() { MainActivity.this.loadHome(); }
        @JavascriptInterface public void loadShorts() { MainActivity.this.loadShorts(); }
        @JavascriptInterface public void setSystemTheme(String mode) { MainActivity.this.setSystemTheme(mode); }
        @JavascriptInterface public void search(String q) { if (q != null && !q.trim().isEmpty()) MainActivity.this.search(q.trim()); }
        @JavascriptInterface public void playVideo(String id) { runOnUiThread(() -> MainActivity.this.openYoutubePlayer(id)); }
        @JavascriptInterface public void enterPip() { runOnUiThread(MainActivity.this::enterPip); }
        @JavascriptInterface public void openYouTubeWeb(String url) { MainActivity.this.openYouTubeWeb(url); }
        @JavascriptInterface public void openExternal(String url) {
            if (url == null) return;
            runOnUiThread(() -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {} });
        }
        @JavascriptInterface public String clientId() { return OAUTH_CLIENT_ID; }
        @JavascriptInterface public String accountName() { return selectedAccount == null ? "" : selectedAccount.name; }
    }
}
