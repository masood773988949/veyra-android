# Veyra 1.0 — Android Personal Build

هذا مشروع Android أصلي باسم **Veyra** وحزمة `com.veyra.player`.

## ما تم ربطه فعليًا
- مشروع Google Cloud: `veyra-personal`
- YouTube Data API v3: مفعّل
- OAuth في وضع Testing للاستخدام الشخصي
- النطاقات: `openid`, `email`, `profile`, `youtube.readonly`
- Android OAuth Client (Release):
  `143368973290-fak6m5rep7uq5lkf85uemr0jcbmbnkom.apps.googleusercontent.com`
- Package: `com.veyra.player`
- Signing SHA-1:
  `CC:37:58:BF:62:35:F5:59:13:48:8B:1E:F7:B6:F2:2B:38:E2:6F:98`

## الوظائف
- اختيار حساب Google من نظام Android.
- طلب صلاحية YouTube للقراءة فقط.
- عرض بيانات القناة.
- جلب الاشتراكات.
- جلب قائمة الفيديوهات التي أعجبتك.
- بحث YouTube عبر Data API.
- مشغل YouTube الرسمي داخل Veyra.
- PiP على Android 8+.
- سجل مشاهدة ومحفوظات محلية داخل التطبيق.
- واجهة عربية RTL داكنة.

## القيود المقصودة
Veyra لا يحجب إعلانات YouTube، ولا يفتح Premium مجانًا، ولا ينزّل محتوى YouTube المحمي. المشاهدة تستخدم مشغل YouTube الرسمي.

## بناء APK في Android Studio
1. افتح هذا المجلد في Android Studio حديث.
2. اسمح له بتنزيل Android SDK 35 وGradle dependencies.
3. اختر Build > Generate App Bundles or APKs > Generate APKs.
4. Release يستخدم المفتاح الموجود في `app/keystore/veyra-release.jks` تلقائيًا.
5. الناتج يكون عادة في `app/build/outputs/apk/release/app-release.apk`.

## مفتاح التوقيع
راجع `SIGNING.txt`. احتفظ به سرًا لأنه ضروري لتثبيت التحديثات المستقبلية بنفس توقيع التطبيق.
