package com.veyra.player;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerCallback;
import android.accounts.AccountManagerFuture;
import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.Gravity;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.browser.customtabs.CustomTabsClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_PICK_ACCOUNT = 101;
    private static final int REQ_AUTH = 102;
    private static final String ACCOUNT_TYPE = "com.google";
    private static final String AUTH_TOKEN_TYPE = "oauth2:https://www.googleapis.com/auth/youtube.readonly";
    public static final String OAUTH_CLIENT_ID = "143368973290-fak6m5rep7uq5lkf85uemr0jcbmbnkom.apps.googleusercontent.com";

    private WebView webView;
    private WebView playerWebView;
    private FrameLayout playerOverlay;
    private FrameLayout root;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private Account selectedAccount;
    private String accessToken;
    private SharedPreferences prefs;

    // Stateful personalized feed pagination. The exact YouTube Home recommendation
    // feed is not exposed to third-party apps, so Veyra pages through uploads from
    // subscribed / recently watched / liked channels instead of using random videos.
    private final List<String> homeChannelIds = new ArrayList<>();
    private final Map<String, String> homeUploadsByChannel = new HashMap<>();
    private final Map<String, String> homeNextPageTokens = new HashMap<>();
    private final Set<String> homeSeenVideoIds = new HashSet<>();
    private final Set<String> homePreferredChannels = new HashSet<>();
    private int homeChannelCursor = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(8,10,15));
        getWindow().setNavigationBarColor(Color.rgb(8,10,15));

        prefs = getSharedPreferences("veyra", MODE_PRIVATE);
        String accountName = prefs.getString("account_name", null);
        if (accountName != null && !accountName.isEmpty()) selectedAccount = new Account(accountName, ACCOUNT_TYPE);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8,10,15));
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) s.setSafeBrowsingEnabled(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new Bridge(this), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view;
                customViewCallback = callback;
                webView.setVisibility(View.GONE);
                root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }
            @Override public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                webView.setVisibility(View.VISIBLE);
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                customViewCallback = null;
            }
        });
        // Load the UI with an HTTPS base origin instead of file://.
        // YouTube embedded playback requires a referrer/client origin; a file:// parent
        // can trigger player configuration error 153 in Android WebView.
        loadAppUi();
    }


    private void loadAppUi() {
        try (InputStream in = getAssets().open("index.html");
             BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder html = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) html.append(line).append('\n');
            webView.loadDataWithBaseURL(
                    "https://veyra.app/",
                    html.toString(),
                    "text/html",
                    "UTF-8",
                    null);
        } catch (Exception e) {
            webView.loadUrl("file:///android_asset/index.html");
        }
    }

    private void pickAccount() {
        Intent intent = AccountManager.newChooseAccountIntent(
                selectedAccount, null, new String[]{ACCOUNT_TYPE}, null, null, null, null);
        startActivityForResult(intent, REQ_PICK_ACCOUNT);
    }

    private void requestToken() {
        if (selectedAccount == null) { pickAccount(); return; }
        AccountManager am = AccountManager.get(this);
        am.getAuthToken(selectedAccount, AUTH_TOKEN_TYPE, null, this,
                new AccountManagerCallback<Bundle>() {
                    @Override public void run(AccountManagerFuture<Bundle> future) {
                        try {
                            Bundle b = future.getResult();
                            Intent consent = b.getParcelable(AccountManager.KEY_INTENT);
                            if (consent != null) {
                                startActivityForResult(consent, REQ_AUTH);
                                return;
                            }
                            String token = b.getString(AccountManager.KEY_AUTHTOKEN);
                            if (token != null && !token.isEmpty()) {
                                accessToken = token;
                                prefs.edit().putString("account_name", selectedAccount.name).apply();
                                sendAuthState(true, selectedAccount.name, null);
                                loadMyChannel();
                            } else sendAuthState(false, selectedAccount.name, "لم يتم استلام رمز الدخول من Google.");
                        } catch (Exception e) {
                            sendAuthState(false, selectedAccount != null ? selectedAccount.name : "", e.getMessage());
                        }
                    }
                }, null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_ACCOUNT && resultCode == RESULT_OK && data != null) {
            String name = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
            String type = data.getStringExtra(AccountManager.KEY_ACCOUNT_TYPE);
            if (name != null) {
                selectedAccount = new Account(name, type == null ? ACCOUNT_TYPE : type);
                accessToken = null;
                requestToken();
            }
        } else if (requestCode == REQ_AUTH) {
            if (resultCode == RESULT_OK) requestToken();
            else sendAuthState(false, selectedAccount != null ? selectedAccount.name : "", "تم إلغاء منح الصلاحية.");
        }
    }

    private void sendAuthState(boolean ok, String email, String error) {
        JSONObject j = new JSONObject();
        try { j.put("ok", ok); j.put("email", email == null ? "" : email); j.put("error", error == null ? JSONObject.NULL : error); }
        catch (JSONException ignored) {}
        js("window.Veyra && Veyra.onAuthState(" + j.toString() + ")");
    }

    private interface TokenWork { void run(String token) throws Exception; }
    private void withToken(TokenWork work) {
        if (accessToken == null) {
            runOnUiThread(this::requestToken);
            js("window.Veyra && Veyra.onError({where:'auth',message:'يتم الآن طلب صلاحية حساب Google. حاول مرة أخرى بعد اكتمال تسجيل الدخول.'})");
            return;
        }
        io.execute(() -> {
            try { work.run(accessToken); }
            catch (Exception e) { sendError("api", e.getMessage()); }
        });
    }

    private String apiGet(String path, String token) throws Exception {
        URL url = new URL("https://www.googleapis.com/youtube/v3/" + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Authorization", "Bearer " + token);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "Veyra/1.1.6 Android");
        int code = c.getResponseCode();
        InputStream in = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(); String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        if (code == 401 && selectedAccount != null) {
            AccountManager.get(this).invalidateAuthToken(ACCOUNT_TYPE, token);
            accessToken = null;
        }
        if (code < 200 || code >= 300) throw new Exception("YouTube API " + code + ": " + sb);
        return sb.toString();
    }

    private void loadMyChannel() {
        withToken(token -> {
            String json = apiGet("channels?part=snippet,contentDetails,statistics&mine=true", token);
            js("window.Veyra && Veyra.onChannel(" + json + ")");
        });
    }

    private void loadSubscriptions() {
        withToken(token -> {
            String json = apiGet("subscriptions?part=snippet,contentDetails&mine=true&maxResults=50&order=relevance", token);
            js("window.Veyra && Veyra.onSubscriptions(" + json + ")");
        });
    }

    private void loadLikes() {
        withToken(token -> {
            JSONObject channels = new JSONObject(apiGet("channels?part=contentDetails&mine=true", token));
            JSONArray items = channels.optJSONArray("items");
            if (items == null || items.length() == 0) throw new Exception("لم يتم العثور على قناة YouTube لهذا الحساب.");
            String playlist = items.getJSONObject(0).getJSONObject("contentDetails").getJSONObject("relatedPlaylists").optString("likes");
            if (playlist.isEmpty()) throw new Exception("قائمة الإعجابات غير متاحة.");
            String json = apiGet("playlistItems?part=snippet,contentDetails&maxResults=50&playlistId=" + URLEncoder.encode(playlist, "UTF-8"), token);
            js("window.Veyra && Veyra.onLikes(" + json + ")");
        });
    }

    private void search(String query) {
        withToken(token -> {
            String q = URLEncoder.encode(query, "UTF-8");
            String json = apiGet("search?part=snippet&type=video&maxResults=30&q=" + q, token);
            js("window.Veyra && Veyra.onSearch(" + json + ")");
        });
    }

    private void loadPlaylists() {
        withToken(token -> {
            String json = apiGet("playlists?part=snippet,contentDetails&mine=true&maxResults=25", token);
            js("window.Veyra && Veyra.onPlaylists(" + json + ")");
        });
    }

    private void loadHome() {
        loadHomeInternal(Collections.emptySet(), true);
    }

    private Set<String> parsePreferredChannels(String preferredChannelIdsJson) {
        Set<String> preferred = new HashSet<>();
        if (preferredChannelIdsJson != null && !preferredChannelIdsJson.trim().isEmpty()) {
            try {
                JSONArray a = new JSONArray(preferredChannelIdsJson);
                for (int i = 0; i < a.length(); i++) {
                    String id = a.optString(i, "").trim();
                    if (!id.isEmpty()) preferred.add(id);
                }
            } catch (Exception ignored) {}
        }
        return preferred;
    }

    private void loadPersonalizedHome(String preferredChannelIdsJson) {
        loadHomeInternal(parsePreferredChannels(preferredChannelIdsJson), true);
    }

    private void loadMorePersonalizedHome(String preferredChannelIdsJson) {
        loadHomeInternal(parsePreferredChannels(preferredChannelIdsJson), false);
    }

    private List<JSONObject> fetchVideoDetailsByIds(String token, List<String> ids) throws Exception {
        List<JSONObject> out = new ArrayList<>();
        for (int start = 0; start < ids.size(); start += 50) {
            int end = Math.min(start + 50, ids.size());
            List<String> chunk = ids.subList(start, end);
            if (chunk.isEmpty()) continue;
            String param = URLEncoder.encode(String.join(",", chunk), "UTF-8");
            JSONObject details = new JSONObject(apiGet(
                    "videos?part=snippet,contentDetails,statistics&id=" + param, token));
            JSONArray items = details.optJSONArray("items");
            if (items == null) continue;
            for (int i = 0; i < items.length(); i++) {
                JSONObject it = items.optJSONObject(i);
                if (it != null) out.add(it);
            }
        }
        return out;
    }

    /**
     * Personalized, paged Veyra home feed. It uses the user's subscriptions plus
     * channels inferred from Veyra watch history / YouTube likes supplied by the UI.
     * Subsequent calls continue through each channel's uploads playlist so Home does
     * not stop after the first small batch and does not fall back to random videos.
     */
    private void loadHomeInternal(Set<String> preferredChannels, boolean reset) {
        withToken(token -> {
            try {
                if (reset || homeChannelIds.isEmpty()) {
                    homeChannelIds.clear();
                    homeUploadsByChannel.clear();
                    homeNextPageTokens.clear();
                    homeSeenVideoIds.clear();
                    homePreferredChannels.clear();
                    homePreferredChannels.addAll(preferredChannels);
                    homeChannelCursor = 0;

                    JSONObject subs = new JSONObject(apiGet(
                            "subscriptions?part=snippet&mine=true&maxResults=50&order=relevance", token));
                    JSONArray subItems = subs.optJSONArray("items");
                    List<String> subscribed = new ArrayList<>();
                    if (subItems != null) {
                        for (int i = 0; i < subItems.length(); i++) {
                            JSONObject sub = subItems.optJSONObject(i);
                            JSONObject sn = sub == null ? null : sub.optJSONObject("snippet");
                            JSONObject rid = sn == null ? null : sn.optJSONObject("resourceId");
                            String id = rid == null ? "" : rid.optString("channelId", "");
                            if (!id.isEmpty() && !subscribed.contains(id)) subscribed.add(id);
                        }
                    }

                    // Watched / liked channels are the strongest signals, even when the
                    // user is not currently subscribed to every one of them.
                    for (String id : preferredChannels) {
                        if (!id.isEmpty() && !homeChannelIds.contains(id)) homeChannelIds.add(id);
                    }
                    for (String id : subscribed) {
                        if (!homeChannelIds.contains(id)) homeChannelIds.add(id);
                    }
                    if (homeChannelIds.size() > 50) {
                        homeChannelIds.subList(50, homeChannelIds.size()).clear();
                    }

                    if (!homeChannelIds.isEmpty()) {
                        String channelParam = URLEncoder.encode(String.join(",", homeChannelIds), "UTF-8");
                        JSONObject channels = new JSONObject(apiGet(
                                "channels?part=contentDetails&id=" + channelParam, token));
                        JSONArray channelItems = channels.optJSONArray("items");
                        if (channelItems != null) {
                            for (int i = 0; i < channelItems.length(); i++) {
                                JSONObject ch = channelItems.optJSONObject(i);
                                if (ch == null) continue;
                                String cid = ch.optString("id", "");
                                JSONObject cd = ch.optJSONObject("contentDetails");
                                JSONObject rp = cd == null ? null : cd.optJSONObject("relatedPlaylists");
                                String uploads = rp == null ? "" : rp.optString("uploads", "");
                                if (!cid.isEmpty() && !uploads.isEmpty()) homeUploadsByChannel.put(cid, uploads);
                            }
                        }
                    }
                } else {
                    homePreferredChannels.addAll(preferredChannels);
                    for (String id : preferredChannels) {
                        if (!id.isEmpty() && !homeChannelIds.contains(id) && homeChannelIds.size() < 50) {
                            homeChannelIds.add(0, id);
                        }
                    }
                }

                JSONArray out = new JSONArray();
                if (homeChannelIds.isEmpty()) {
                    JSONObject payload = new JSONObject();
                    payload.put("items", out);
                    payload.put("hasMore", false);
                    js("window.Veyra && Veyra." + (reset ? "onHome" : "onHomeMore") + "(" + payload + ")");
                    return;
                }

                List<String> candidateIds = new ArrayList<>();
                int channelsVisited = 0;
                int attempts = 0;
                int targetChannels = Math.min(10, homeChannelIds.size());
                boolean anyMore = false;

                while (channelsVisited < targetChannels && attempts < homeChannelIds.size() * 2) {
                    String cid = homeChannelIds.get(homeChannelCursor % homeChannelIds.size());
                    homeChannelCursor = (homeChannelCursor + 1) % Math.max(1, homeChannelIds.size());
                    attempts++;
                    String uploads = homeUploadsByChannel.get(cid);
                    if (uploads == null || uploads.isEmpty()) continue;
                    String pageToken = homeNextPageTokens.get(cid);
                    if ("__END__".equals(pageToken)) continue;

                    String path = "playlistItems?part=contentDetails&maxResults=6&playlistId="
                            + URLEncoder.encode(uploads, "UTF-8");
                    if (pageToken != null && !pageToken.isEmpty()) {
                        path += "&pageToken=" + URLEncoder.encode(pageToken, "UTF-8");
                    }
                    JSONObject pl = new JSONObject(apiGet(path, token));
                    String next = pl.optString("nextPageToken", "");
                    homeNextPageTokens.put(cid, next.isEmpty() ? "__END__" : next);
                    if (!next.isEmpty()) anyMore = true;
                    JSONArray items = pl.optJSONArray("items");
                    if (items != null) {
                        for (int j = 0; j < items.length(); j++) {
                            JSONObject it = items.optJSONObject(j);
                            JSONObject cd = it == null ? null : it.optJSONObject("contentDetails");
                            String videoId = cd == null ? "" : cd.optString("videoId", "");
                            if (!videoId.isEmpty() && homeSeenVideoIds.add(videoId)) candidateIds.add(videoId);
                        }
                    }
                    channelsVisited++;
                }

                List<JSONObject> details = fetchVideoDetailsByIds(token, candidateIds);
                List<JSONObject> normalVideos = new ArrayList<>();
                List<JSONObject> fallbackAnyLength = new ArrayList<>();
                for (JSONObject it : details) {
                    if (it == null) continue;
                    fallbackAnyLength.add(it);
                    JSONObject cd = it.optJSONObject("contentDetails");
                    long seconds = durationSeconds(cd == null ? "" : cd.optString("duration", ""));
                    if (seconds == Long.MAX_VALUE || seconds > 180) normalVideos.add(it);
                }
                if (normalVideos.isEmpty()) normalVideos = fallbackAnyLength;

                Collections.sort(normalVideos, (a, b) -> {
                    JSONObject sa = a.optJSONObject("snippet"), sb = b.optJSONObject("snippet");
                    String ca = sa == null ? "" : sa.optString("channelId", "");
                    String cb = sb == null ? "" : sb.optString("channelId", "");
                    boolean pa = homePreferredChannels.contains(ca), pb = homePreferredChannels.contains(cb);
                    if (pa != pb) return pa ? -1 : 1;
                    String da = sa == null ? "" : sa.optString("publishedAt", "");
                    String db = sb == null ? "" : sb.optString("publishedAt", "");
                    return db.compareTo(da);
                });
                for (JSONObject it : normalVideos) out.put(it);

                if (!anyMore) {
                    for (String v : homeNextPageTokens.values()) {
                        if (v != null && !v.isEmpty() && !"__END__".equals(v)) { anyMore = true; break; }
                    }
                }
                // If some channels were not visited in this batch, there is still more
                // personalized content to request even if the current channels ended.
                if (homeChannelIds.size() > targetChannels) anyMore = true;

                JSONObject payload = new JSONObject();
                payload.put("items", out);
                payload.put("hasMore", anyMore || out.length() > 0);
                payload.put("veyraFeed", "account_personalized_paged");
                js("window.Veyra && Veyra." + (reset ? "onHome" : "onHomeMore") + "(" + payload + ")");
            } catch (Exception e) {
                JSONObject payload = new JSONObject();
                payload.put("items", new JSONArray());
                payload.put("hasMore", false);
                js("window.Veyra && Veyra." + (reset ? "onHome" : "onHomeMore") + "(" + payload + ")");
                throw e;
            }
        });
    }

    private void loadShorts() {
        loadShortsInternal(Collections.emptySet());
    }

    private void loadPersonalizedShorts(String preferredChannelIdsJson) {
        loadShortsInternal(parsePreferredChannels(preferredChannelIdsJson));
    }

    private long durationSeconds(String iso) {
        if (iso == null || iso.isEmpty() || !iso.startsWith("PT")) return Long.MAX_VALUE;
        long h = 0, m = 0, sec = 0;
        StringBuilder n = new StringBuilder();
        for (int i = 2; i < iso.length(); i++) {
            char c = iso.charAt(i);
            if (Character.isDigit(c)) { n.append(c); continue; }
            long v = n.length() == 0 ? 0 : Long.parseLong(n.toString());
            n.setLength(0);
            if (c == 'H') h = v; else if (c == 'M') m = v; else if (c == 'S') sec = v;
        }
        return h * 3600L + m * 60L + sec;
    }

    /**
     * Builds a Shorts feed from the user's subscriptions and interests. The exact
     * official YouTube Shorts recommendation feed is not exposed by Data API, so
     * Veyra prioritizes recent <=3 minute uploads from subscribed channels, moves
     * recently watched channels first, and supplements with liked short videos.
     */
    private void loadShortsInternal(Set<String> preferredChannels) {
        withToken(token -> {
            try {
                JSONObject subs = new JSONObject(apiGet(
                        "subscriptions?part=snippet&mine=true&maxResults=30&order=relevance", token));
                JSONArray subItems = subs.optJSONArray("items");
                List<String> channelIds = new ArrayList<>();
                if (subItems != null) {
                    for (int i = 0; i < subItems.length(); i++) {
                        JSONObject sub = subItems.optJSONObject(i);
                        JSONObject sn = sub == null ? null : sub.optJSONObject("snippet");
                        JSONObject rid = sn == null ? null : sn.optJSONObject("resourceId");
                        String id = rid == null ? "" : rid.optString("channelId", "");
                        if (!id.isEmpty() && !channelIds.contains(id)) channelIds.add(id);
                    }
                }

                if (!preferredChannels.isEmpty()) {
                    List<String> reordered = new ArrayList<>();
                    for (String id : preferredChannels) if (!id.isEmpty() && !reordered.contains(id)) reordered.add(id);
                    for (String id : channelIds) if (!reordered.contains(id)) reordered.add(id);
                    channelIds = reordered;
                }

                List<String> selected = channelIds.subList(0, Math.min(20, channelIds.size()));
                Map<String, String> uploadsByChannel = new HashMap<>();
                if (!selected.isEmpty()) {
                    String channelParam = URLEncoder.encode(String.join(",", selected), "UTF-8");
                    JSONObject channels = new JSONObject(apiGet(
                            "channels?part=contentDetails&id=" + channelParam, token));
                    JSONArray channelItems = channels.optJSONArray("items");
                    if (channelItems != null) {
                        for (int i = 0; i < channelItems.length(); i++) {
                            JSONObject ch = channelItems.optJSONObject(i);
                            if (ch == null) continue;
                            String cid = ch.optString("id", "");
                            JSONObject cd = ch.optJSONObject("contentDetails");
                            JSONObject rp = cd == null ? null : cd.optJSONObject("relatedPlaylists");
                            String uploads = rp == null ? "" : rp.optString("uploads", "");
                            if (!cid.isEmpty() && !uploads.isEmpty()) uploadsByChannel.put(cid, uploads);
                        }
                    }
                }

                List<String> candidateIds = new ArrayList<>();
                for (String cid : selected) {
                    String uploads = uploadsByChannel.get(cid);
                    if (uploads == null || uploads.isEmpty()) continue;
                    JSONObject pl = new JSONObject(apiGet(
                            "playlistItems?part=contentDetails&maxResults=10&playlistId="
                                    + URLEncoder.encode(uploads, "UTF-8"), token));
                    JSONArray items = pl.optJSONArray("items");
                    if (items == null) continue;
                    for (int j = 0; j < items.length(); j++) {
                        JSONObject it = items.optJSONObject(j);
                        JSONObject cd = it == null ? null : it.optJSONObject("contentDetails");
                        String videoId = cd == null ? "" : cd.optString("videoId", "");
                        if (!videoId.isEmpty() && !candidateIds.contains(videoId)) candidateIds.add(videoId);
                        if (candidateIds.size() >= 100) break;
                    }
                    if (candidateIds.size() >= 100) break;
                }

                List<JSONObject> personalized = new ArrayList<>();
                Set<String> seen = new HashSet<>();
                if (!candidateIds.isEmpty()) {
                    List<JSONObject> items = fetchVideoDetailsByIds(token, candidateIds);
                    for (JSONObject it : items) {
                        if (it == null) continue;
                        JSONObject cd = it.optJSONObject("contentDetails");
                        long seconds = durationSeconds(cd == null ? "" : cd.optString("duration", ""));
                        if (seconds > 0 && seconds <= 180) { personalized.add(it); seen.add(it.optString("id", "")); }
                    }
                }

                // Liked short videos are a strong interest signal and cost only one API call.
                try {
                    JSONObject liked = new JSONObject(apiGet(
                            "videos?part=snippet,contentDetails,statistics&myRating=like&maxResults=25", token));
                    JSONArray likedItems = liked.optJSONArray("items");
                    if (likedItems != null) {
                        for (int i = 0; i < likedItems.length() && personalized.size() < 40; i++) {
                            JSONObject it = likedItems.optJSONObject(i);
                            if (it == null) continue;
                            String id = it.optString("id", "");
                            JSONObject cd = it.optJSONObject("contentDetails");
                            long seconds = durationSeconds(cd == null ? "" : cd.optString("duration", ""));
                            if (!seen.contains(id) && seconds > 0 && seconds <= 180) { personalized.add(it); seen.add(id); }
                        }
                    }
                } catch (Exception ignored) {}

                Collections.sort(personalized, (a, b) -> {
                    JSONObject sa = a.optJSONObject("snippet"), sb = b.optJSONObject("snippet");
                    String ca = sa == null ? "" : sa.optString("channelId", "");
                    String cb = sb == null ? "" : sb.optString("channelId", "");
                    boolean pa = preferredChannels.contains(ca), pb = preferredChannels.contains(cb);
                    if (pa != pb) return pa ? -1 : 1;
                    String da = sa == null ? "" : sa.optString("publishedAt", "");
                    String db = sb == null ? "" : sb.optString("publishedAt", "");
                    return db.compareTo(da);
                });

                // No generic/random #shorts fallback: if personalized sources are sparse,
                // Veyra shows fewer items rather than replacing them with unrelated Shorts.

                JSONArray out = new JSONArray();
                for (int i = 0; i < personalized.size() && i < 40; i++) out.put(personalized.get(i));
                JSONObject payload = new JSONObject();
                payload.put("items", out);
                payload.put("veyraFeed", "personalized_shorts");
                js("window.Veyra && Veyra.onShorts(" + payload.toString() + ")");
            } catch (Exception e) {
                JSONObject payload = new JSONObject();
                payload.put("items", new JSONArray());
                payload.put("veyraFeed", "personalized_shorts");
                js("window.Veyra && Veyra.onShorts(" + payload + ")");
                throw e;
            }
        });
    }

    private void sendError(String where, String msg) {
        JSONObject j = new JSONObject();
        try { j.put("where", where); j.put("message", msg == null ? "خطأ غير معروف" : msg); } catch (JSONException ignored) {}
        js("window.Veyra && Veyra.onError(" + j.toString() + ")");
    }

    private void js(String script) {
        runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }

    private void logout() {
        if (accessToken != null) AccountManager.get(this).invalidateAuthToken(ACCOUNT_TYPE, accessToken);
        accessToken = null; selectedAccount = null;
        prefs.edit().remove("account_name").apply();
        sendAuthState(false, "", null);
        js("window.Veyra && Veyra.resetAccount()");
    }

    private void openYoutubePlayer(String videoId) {
        if (videoId == null || !videoId.matches("[A-Za-z0-9_-]{6,20}")) {
            sendError("player", "معرّف الفيديو غير صالح.");
            return;
        }
        closeYoutubePlayer();

        playerOverlay = new FrameLayout(this);
        playerOverlay.setBackgroundColor(Color.BLACK);

        playerWebView = new WebView(this);
        WebSettings ps = playerWebView.getSettings();
        ps.setJavaScriptEnabled(true);
        ps.setDomStorageEnabled(true);
        ps.setMediaPlaybackRequiresUserGesture(false);
        ps.setLoadWithOverviewMode(true);
        ps.setUseWideViewPort(true);
        ps.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ps.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(playerWebView, true);

        playerWebView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String host = u.getHost() == null ? "" : u.getHost();
                if ("https".equals(u.getScheme()) && (host.endsWith("youtube.com") || host.endsWith("googlevideo.com") || host.endsWith("ytimg.com"))) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });
        playerWebView.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view;
                customViewCallback = callback;
                playerWebView.setVisibility(View.GONE);
                root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }
            @Override public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                if (playerWebView != null) playerWebView.setVisibility(View.VISIBLE);
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                customViewCallback = null;
            }
        });

        playerOverlay.addView(playerWebView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextColor(Color.WHITE);
        close.setTextSize(26f);
        close.setGravity(Gravity.CENTER);
        close.setBackgroundColor(Color.argb(170, 0, 0, 0));
        close.setOnClickListener(v -> closeYoutubePlayer());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(64, 64, Gravity.TOP | Gravity.END);
        cp.setMargins(0, 18, 18, 0);
        playerOverlay.addView(close, cp);

        root.addView(playerOverlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        String url = "https://www.youtube.com/embed/" + Uri.encode(videoId)
                + "?autoplay=1&playsinline=1&rel=0";
        Map<String, String> headers = new HashMap<>();
        // YouTube requires HTTP Referer (or equivalent client identification)
        // for embedded playback in Android WebView. The package ID is used as
        // a stable app identity, per YouTube's API Client Identity guidance.
        headers.put("Referer", "https://com.veyra.player/");
        playerWebView.loadUrl(url, headers);
    }

    private void closeYoutubePlayer() {
        if (customView != null && playerWebView != null) {
            try { ((WebChromeClient) playerWebView.getWebChromeClient()).onHideCustomView(); } catch (Exception ignored) {}
        }
        if (playerOverlay != null) {
            root.removeView(playerOverlay);
            playerOverlay = null;
        }
        if (playerWebView != null) {
            try { playerWebView.stopLoading(); playerWebView.loadUrl("about:blank"); playerWebView.destroy(); } catch (Exception ignored) {}
            playerWebView = null;
        }
    }


    /**
     * Opens YouTube in a secure browser-backed Custom Tab. This intentionally does
     * not perform Google sign-in inside WebView: Google blocks OAuth authentication
     * in embedded user agents. A Custom Tab reuses the user's supported browser
     * session, so pages such as YouTube History can show the account's real data
     * when that browser is signed in.
     */
    private void openYouTubeWeb(String url) {
        if (url == null) return;
        Uri uri;
        try { uri = Uri.parse(url); } catch (Exception e) { return; }
        String scheme = uri.getScheme() == null ? "" : uri.getScheme();
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
        if (!"https".equals(scheme) || !(host.equals("youtube.com") || host.endsWith(".youtube.com"))) {
            sendError("youtube_web", "لا يمكن فتح هذا الرابط داخل جلسة YouTube.");
            return;
        }
        runOnUiThread(() -> {
            try {
                CustomTabColorSchemeParams colors = new CustomTabColorSchemeParams.Builder()
                        .setToolbarColor(Color.rgb(15, 15, 15))
                        .setNavigationBarColor(Color.rgb(15, 15, 15))
                        .build();
                CustomTabsIntent tab = new CustomTabsIntent.Builder()
                        .setShowTitle(true)
                        .setUrlBarHidingEnabled(true)
                        .setDefaultColorSchemeParams(colors)
                        .build();
                // Force a browser Custom Tab so Android does not hand YouTube URLs
                // to the standalone YouTube app. This keeps the user in Veyra's
                // browser-backed flow while preserving the browser's signed-in session.
                String browserPackage = CustomTabsClient.getPackageName(MainActivity.this, null);
                if (browserPackage != null && !browserPackage.isEmpty()) tab.intent.setPackage(browserPackage);
                tab.intent.putExtra(Intent.EXTRA_REFERRER, Uri.parse("android-app://" + getPackageName()));
                tab.launchUrl(MainActivity.this, uri);
            } catch (Exception e) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                catch (Exception ignored) { sendError("youtube_web", "لم يتم العثور على متصفح مدعوم."); }
            }
        });
    }


    private void setSystemTheme(String mode) {
        boolean dark = !"light".equalsIgnoreCase(mode);
        runOnUiThread(() -> {
            int bg = dark ? Color.rgb(15, 15, 15) : Color.WHITE;
            getWindow().setStatusBarColor(bg);
            getWindow().setNavigationBarColor(bg);
            if (root != null) root.setBackgroundColor(bg);
            int flags = 0;
            if (!dark && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (!dark && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        });
    }

    private void enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                PictureInPictureParams p = new PictureInPictureParams.Builder().setAspectRatio(new Rational(16, 9)).build();
                enterPictureInPictureMode(p);
            } catch (Exception e) { sendError("pip", e.getMessage()); }
        }
    }

    @Override public void onBackPressed() {
        if (customView != null) {
            try {
                WebView target = playerWebView != null ? playerWebView : webView;
                ((WebChromeClient) target.getWebChromeClient()).onHideCustomView();
            } catch (Exception ignored) {}
            return;
        }
        if (playerOverlay != null) { closeYoutubePlayer(); return; }
        if (webView == null) { finish(); return; }

        // Veyra navigation rule: any internal page -> Home; Home -> exit.
        // If a video page is open, JavaScript minimizes it to the mini player first.
        webView.evaluateJavascript(
                "(function(){try{return (window.Veyra&&Veyra.handleAndroidBack)?Veyra.handleAndroidBack():'exit'}catch(e){return 'exit'}})()",
                value -> {
                    if (value == null || "\"exit\"".equals(value) || "null".equals(value)) finish();
                });
    }

    @Override protected void onDestroy() {
        closeYoutubePlayer();
        io.shutdownNow();
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }

    public class Bridge {
        private final Context context;
        Bridge(Context c) { context = c; }
        @JavascriptInterface public void login() { runOnUiThread(MainActivity.this::pickAccount); }
        @JavascriptInterface public void refreshToken() { runOnUiThread(MainActivity.this::requestToken); }
        @JavascriptInterface public void logout() { runOnUiThread(MainActivity.this::logout); }
        @JavascriptInterface public void loadChannel() { loadMyChannel(); }
        @JavascriptInterface public void loadSubscriptions() { MainActivity.this.loadSubscriptions(); }
        @JavascriptInterface public void loadLikes() { MainActivity.this.loadLikes(); }
        @JavascriptInterface public void loadPlaylists() { MainActivity.this.loadPlaylists(); }
        @JavascriptInterface public void loadHome() { MainActivity.this.loadHome(); }
        @JavascriptInterface public void loadPersonalizedHome(String preferredChannelIdsJson) { MainActivity.this.loadPersonalizedHome(preferredChannelIdsJson); }
        @JavascriptInterface public void loadMorePersonalizedHome(String preferredChannelIdsJson) { MainActivity.this.loadMorePersonalizedHome(preferredChannelIdsJson); }
        @JavascriptInterface public void loadShorts() { MainActivity.this.loadShorts(); }
        @JavascriptInterface public void loadPersonalizedShorts(String preferredChannelIdsJson) { MainActivity.this.loadPersonalizedShorts(preferredChannelIdsJson); }
        @JavascriptInterface public void setSystemTheme(String mode) { MainActivity.this.setSystemTheme(mode); }
        @JavascriptInterface public void search(String q) { if (q != null && !q.trim().isEmpty()) MainActivity.this.search(q.trim()); }
        @JavascriptInterface public void playVideo(String id) { runOnUiThread(() -> MainActivity.this.openYoutubePlayer(id)); }
        @JavascriptInterface public void enterPip() { runOnUiThread(MainActivity.this::enterPip); }
        @JavascriptInterface public void openYouTubeWeb(String url) { MainActivity.this.openYouTubeWeb(url); }
        @JavascriptInterface public void openExternal(String url) {
            if (url == null) return;
            runOnUiThread(() -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {} });
        }
        @JavascriptInterface public String clientId() { return OAUTH_CLIENT_ID; }
        @JavascriptInterface public String accountName() { return selectedAccount == null ? "" : selectedAccount.name; }
    }
}
